function [plotmask] = plotFromAdjacency(adjMat, plotThreshold, whichFunction)
%PLOTFROMADJACENCY Summary of this function goes here
%   Detailed explanation goes here

% Determine plot threshold
flattemp = sort(adjMat(:));
plotmask = flattemp(max(1,ceil(length(flattemp)*(1-plotThreshold))));
plotmask = (adjMat>plotmask).*(ones([48 48])-diag(ones([1 48])));
maxnotdiag = max(max(adjMat.*plotmask));

% DPI

for i = 1:48
    for j = i:48
        for k = j:48
            if plotmask(i,j) > 0 && plotmask(j,k) > 0 && plotmask(i,k) > 0
                if (adjMat(i,j) < adjMat(j,k)) && (adjMat(i,j) < adjMat(i,k))
                    plotmask(i,j) = 0;
                    plotmask(j,i) = 0;
                elseif (adjMat(j,k) < adjMat(i,j)) && (adjMat(j,k) < adjMat(i,k))
                    plotmask(j,k) = 0;
                    plotmask(k,j) = 0;
                end
            end
        end
    end
end
            

% Create figure
close all;
figure1 = figure('Colormap',...
    [0.0416666679084301 0 0;0.0833333358168602 0 0;0.125 0 0;0.16666667163372 0 0;0.20833332836628 0 0;0.25 0 0;0.291666656732559 0 0;0.333333343267441 0 0;0.375 0 0;0.416666656732559 0 0;0.458333343267441 0 0;0.5 0 0;0.541666686534882 0 0;0.583333313465118 0 0;0.625 0 0;0.666666686534882 0 0;0.708333313465118 0 0;0.75 0 0;0.791666686534882 0 0;0.833333313465118 0 0;0.875 0 0;0.916666686534882 0 0;0.958333313465118 0 0;1 0 0;1 0.0416666679084301 0;1 0.0833333358168602 0;1 0.125 0;1 0.16666667163372 0;1 0.20833332836628 0;1 0.25 0;1 0.291666656732559 0;1 0.333333343267441 0;1 0.375 0;1 0.416666656732559 0;1 0.458333343267441 0;1 0.5 0;1 0.541666686534882 0;1 0.583333313465118 0;1 0.625 0;1 0.666666686534882 0;1 0.708333313465118 0;1 0.75 0;1 0.791666686534882 0;1 0.833333313465118 0;1 0.875 0;1 0.916666686534882 0;1 0.958333313465118 0;1 1 0;1 1 0.0625;1 1 0.125;1 1 0.1875;1 1 0.25;1 1 0.3125;1 1 0.375;1 1 0.4375;1 1 0.5;1 1 0.5625;1 1 0.625;1 1 0.6875;1 1 0.75;1 1 0.8125;1 1 0.875;1 1 0.9375;1 1 1]);

% Create axes
axes1 = axes('Parent',figure1,...
    'YTickLabel',{'0','4','8','12','16','20','24','28','32','36','40','44','48'},...
    'YTick',[0 4 8 12 16 20 24 28 32 36 40 44 48],...
    'YDir','reverse',...
    'XTickLabel',{'0','4','8','12','16','20','24','28','32','26','40','44','48'},...
    'XTick',[0 4 8 12 16 20 24 28 32 36 40 44 48],...
    'Layer','top',...
    'CLim',[max(0,flattemp(1)) maxnotdiag]);
% Uncomment the following line to preserve the X-limits of the axes
xlim(axes1,[0.5 48.5]);
% Uncomment the following line to preserve the Y-limits of the axes
ylim(axes1,[0.5 48.5]);
box(axes1,'on');
hold(axes1,'all');

% Create image
image(adjMat.*plotmask + diag(min(adjMat(1,1),maxnotdiag)*ones([1 48])),'Parent',axes1,'CDataMapping','scaled');
title({sprintf('%s: Top %.2f%%', whichFunction, plotThreshold*100)});
colorbar('peer',axes1);
grid on;
set(gca,'Xcolor',[0.5 0.5 0.5]);
set(gca,'Ycolor',[0.5 0.5 0.5]);

end

